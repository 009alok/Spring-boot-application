package eu.dreamix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealTimeReportingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealTimeReportingApplication.class, args);
	}
}
