package com.stockmarket.springboot.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stockmarket.springboot.model.StockData;
import com.stockmarket.springboot.repository.StockDataRepository;
import com.stockmarket.springboot.repository.StockRepository;

@Service
public class ShareMarketService {

	@Autowired
	StockDataRepository stockDataRepository;
	
	@Autowired
	StockRepository stockRepository;
	
	public Map<String,String> getClosingPriceForParticularDate(String year,String month, String date){
		StockData stockData = new StockData();
		Map<String,String> record = new HashMap<>();
		String wholeDate =year+"-"+month+"-"+date;
		Date id = null;
		try {
			id = new SimpleDateFormat("yyyy-MM-dd").parse(wholeDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		 
		stockData = stockDataRepository.getOne(id);
		String dateToShown =date+"-"+month+"-"+year;		
		record.put(dateToShown, stockData.getClose());
		
		return record;
	}
	
	public Map<String,String> getClosingPriceForParticularMonth(String year,String month){		
		Map<String,String> record = new HashMap<>();
		List<StockData> list=stockRepository.findByYearAndMonth(month, year);
				
		list.forEach((n)->{
			
			String dateFromRepository = n.getDate().toString();
			String closePrice = n.getClose();			
			record.put(dateFromRepository, closePrice);
		});		
		
		return record;
	}
	
	public Map<String,String> getClosingPriceForParticularYear(String year){		
		Map<String,String> record = new HashMap<>();
		
		for(int i=1;i<=12;i++){			
			List<StockData> list=stockRepository.findByYearAndMonth(String.valueOf(i), year);
			if(list != null){
				Double sum=0.0;
				for(StockData s:list){
					Double d=Double.parseDouble(s.getClose());
					sum=sum+d;
				}
				sum = sum/list.size();
				record.put(String.valueOf(i), sum.toString());
			}
		}
		
		return record;
	}
}
