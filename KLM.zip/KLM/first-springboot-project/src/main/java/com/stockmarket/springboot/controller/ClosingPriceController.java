package com.stockmarket.springboot.controller;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stockmarket.springboot.service.ShareMarketService;

@RestController
@RequestMapping("/{year}")
public class ClosingPriceController {
	
	@Autowired
	ShareMarketService shareMarketService;
	
	@GetMapping
	public Map<String,String> getClosingPriceForParticularYear(@PathVariable("year")String year){
		return shareMarketService.getClosingPriceForParticularYear(year);
	} 
	
	@GetMapping("/{month}")
	public Map<String,String> getClosingPriceForParticularMonth(@PathVariable("year")String year, @PathVariable ("month")String month){
		return shareMarketService.getClosingPriceForParticularMonth(year,month);
	}

	@GetMapping("/{month}/{date}")
	public Map<String, String> getClosingPriceForParticularDate(@PathVariable ("year")String year,@PathVariable ("month")String month,
																@PathVariable ("date")String date){
		return shareMarketService.getClosingPriceForParticularDate(year,month,date);		
	}
}
