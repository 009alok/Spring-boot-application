package com.stockmarket.springboot.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.stockmarket.springboot.model.StockData;
import com.stockmarket.springboot.repository.StockDataRepository;

@Component
public class DBWriter implements ItemWriter<StockData>{

	@Autowired
	private StockDataRepository stockDataRepository;
	@Override
	public void write(List<? extends StockData> stockData) throws Exception {

		System.out.println("Data saved for stocks");
		stockDataRepository.save(stockData);		
	}
	

}
