package com.stockmarket.springboot.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stockmarket.springboot.model.StockData;
@Repository
public interface StockDataRepository extends JpaRepository<StockData, Date>{

}
