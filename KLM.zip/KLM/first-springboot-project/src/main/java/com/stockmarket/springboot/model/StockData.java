package com.stockmarket.springboot.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StockData {

	@Id
	private Date date;
	private String open;
	private String high;
	private String low;
	private String close;
	private String adj;
	private String volume;
		
	public StockData(Date date, String open, String high, String low, String close,
			String adj, String volume) {
		super();
		this.date = date;
		this.open = open;
		this.high = high;
		this.low = low;
		this.close = close;
		this.adj = adj;
		this.volume = volume;
	}

	public StockData() {		
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getopen() {
		return open;
	}

	public void setopen(String open) {
		this.open = open;
	}

	public String getHigh() {
		return high;
	}

	public void setHigh(String high) {
		this.high = high;
	}

	public String getLow() {
		return low;
	}

	public void setLow(String low) {
		this.low = low;
	}

	public String getClose() {
		return close;
	}

	public void setClose(String close) {
		this.close = close;
	}

	public String getAdj() {
		return adj;
	}

	public void setAdj(String adj) {
		this.adj = adj;
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	@Override
	public String toString() {
		return "StockData [date=" + date + ", open=" + open + ", high=" + high + ", low=" + low + ", close=" + close
				+ ", adj=" + adj + ", volume=" + volume + "]";
	}		
	
}
