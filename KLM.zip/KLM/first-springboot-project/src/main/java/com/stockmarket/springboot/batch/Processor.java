package com.stockmarket.springboot.batch;

import com.stockmarket.springboot.model.StockData;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class Processor implements ItemProcessor<StockData,StockData> {

	@Override
	public StockData process(StockData stockData) throws Exception {
		// TODO Auto-generated method stub		
		return stockData;
	}

}
