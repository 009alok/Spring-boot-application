package com.stockmarket.springboot.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stockmarket.springboot.model.StockData;

@Repository
public interface StockRepository extends CrudRepository<StockData, Date>{

	@Query(value="select * from stock_data WHERE MONTH(date) =?1 AND YEAR(date) =?2",nativeQuery = true)
	List<StockData> findByYearAndMonth(String month,String year);
	
}
